# Arca — código fuente

Contenedor de sub-apps Rust para Android. Blueprint: `../arca-blueprint/`.

## Estado (F0+F1+F2 implementadas, PC-verificables)

| Fase | Estado | Contenido |
|---|---|---|
| F0 (T01) | ✔ | Workspace 33 crates, justfile, check-graphs, toolchain fijado |
| F0 (T02) | ⏳ código listo | `host-probe/` (APK targetSdk 28) + `devapp-hello` — **ejecutar en tu teléfono = gate GO/NO-GO** |
| F1 (T03-T09) | ✔ | types, pkg-model, 7z, sign, store, installer, tools-pk — pipeline `.arca` completo |
| F2 (T10-T16) | ✔ | **protocol, shm, ipc, exec-abi, permissions, exec-native, rt** — ejecución nativa headless con sandbox seccomp REAL |

- **312 tests verdes** · `clippy -D warnings` verde · grafo sin ciclos (`scripts/check-graphs.py`)
- E2E del backend nativo (PC): spawn → handshake → **ping p99 = 46 µs** (presupuesto 1 ms) → kill-9 → Dead ≤ 50 ms; 100 spawns sin zombis; **seccomp probado** (socket() → SIGSYS); panic de app → exit 101.

## Uso rápido (PC/Deepin)

```bash
export PATH="$HOME/.cargo/bin:$PATH"
cargo build                                        # compila TODO (incluido arca-launch)
cargo test --workspace                             # 312 tests (≈35 s: incluye forks reales)

# E2E del backend nativo (requiere la app de prueba ESTÁTICA — el sandbox
# bloquea openat y una app dinámica moriría en el loader):
rustup target add x86_64-unknown-linux-musl
cargo build -p arca-rt --bin arca-ping --target x86_64-unknown-linux-musl
cargo test -p arca-exec-native --test e2e -- --nocapture   # logs del hijo visibles
```

Pipeline de empaquetado (F1):

```bash
cargo run -p arca-tools-pk -- keygen --out ~/.arca/keys
cargo run -p arca-tools-pk -- pack --src miapp/ --out miapp-1.0.0.arca --key ~/.arca/keys/signing.key --backend native
cargo run -p arca-tools-pk -- verify --file miapp-1.0.0.arca --pubkey ~/.arca/keys/signing.pub
```

## Siguiente paso CRÍTICO (gate F0)

Compilar `host-probe` y correrlo en el teléfono → `host-probe/decision.md`:
ver `host-probe/README.md`. Si exec OK → **F3** (gfx-protocol/input/wm/
compositor/sdk + host-core). Si FAIL → pivot WASM-first (T25).

## CI local

`just default` (o `scripts/ci.sh`): fmt-check + clippy -D warnings + test + check-graphs.
