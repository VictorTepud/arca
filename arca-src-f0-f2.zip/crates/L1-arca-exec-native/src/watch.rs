//! Watcher de vida de la instancia: handshake + reap (waitpid) + drain.

use std::os::fd::AsFd as _;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use arca_exec_abi::{AppEvent, DeathReason, HandleDriver};
use arca_ipc::{handshake_server, Conn};
use arca_protocol::ShmLayout;
use arca_shm::Memfd;
use nix::sys::wait::{waitpid, WaitPidFlag, WaitStatus};
use nix::unistd::Pid;
use std::os::fd::OwnedFd;
use tracing::{info, warn};

use crate::bus::ConnBus;
use crate::spec::LaunchSpec;

/// Periodo del poll de reap (5 ms ⇒ detección de muerte ≤ ~10 ms;
/// presupuesto spec 14 §6: ≤ 50 ms).
const REAP_POLL_MS: u64 = 5;

/// Estado del hilo watcher (uno por instancia).
pub(crate) struct WatchCtx {
    /// Pid de la app (waitpid/kill).
    pub pid: Pid,
    /// Extremo host del socketpair (AIPC ctl).
    pub conn: Conn,
    /// Spec serializable (identidad esperada del handshake).
    pub spec: LaunchSpec,
    /// memfds a entregar por SCM_RIGHTS en WELCOME (orden: frames, input).
    pub memfds: Vec<Memfd>,
    /// Geometría shm anunciada.
    pub layout: ShmLayout,
    /// Ventanas del Attach v1.
    pub windows: Vec<arca_protocol::WindowSpec>,
    /// Bus compartido (se instala la Conn tras el handshake).
    pub bus: Arc<Mutex<ConnBus>>,
    /// Driver de eventos del handle.
    pub driver: HandleDriver,
}

/// Hilo de vigilancia: handshake → Hello/Ready → reap loop → Dead.
pub(crate) fn watch(ctx: WatchCtx) {
    // Destructure completo: sin moves parciales (todos los campos se usan).
    let WatchCtx {
        pid,
        conn,
        spec,
        memfds,
        layout,
        windows,
        bus,
        driver,
    } = ctx;
    // 1) handshake (bloquea ≤ 2 s: deadline interno de arca-ipc).
    let expect = match arca_types::AppId::new(&spec.app_id) {
        Ok(a) => arca_ipc::HelloExpect {
            app_id: a,
            instance: arca_types::InstanceId::new(spec.instance),
            artifact_hash: arca_types::Digest(spec.artifact),
        },
        Err(e) => {
            warn!(target: "arca::exec-native::watch", err = %e, "app_id inválido en spec");
            let _ = waitpid(pid, Some(WaitPidFlag::WNOHANG));
            driver.report_death(DeathReason::Lost, None);
            return;
        }
    };
    let caps: Vec<arca_types::Capability> = arca_types::Capability::all()
        .iter()
        .copied()
        .filter(|c| spec.caps_bits & (1u32 << c.index()) != 0)
        .collect();
    let mut conn = conn;
    let raw_fds: Vec<std::os::fd::RawFd> = memfds.iter().map(|m| m.raw_fd()).collect();
    match handshake_server(&mut conn, &expect, &raw_fds, layout, &caps, &windows) {
        Ok(_ready) => {
            // Invariante de orden: la Conn se instala ANTES de emitir Ready
            // (el host reacciona a Ready enviando mensajes al instante).
            if let Ok(mut b) = bus.lock() {
                b.install(conn);
            }
            // Invariante ABI: Hello antes que Ready; Spawned lo emitió launch.
            driver.emit(AppEvent::Hello);
            driver.emit(AppEvent::Ready);
        }
        Err(e) => {
            warn!(target: "arca::exec-native::watch", err = %e, pid = pid.as_raw(), "handshake falló");
            let _ = waitpid(pid, Some(WaitPidFlag::WNOHANG));
            driver.report_death(DeathReason::Lost, None);
            return;
        }
    }

    // Invariante: los Memfd viven hasta aquí (cerrados tras el sendmsg).
    drop(memfds);
    // 2) reap loop (WNOHANG: sin zombis, sin bloqueo).
    loop {
        match waitpid(pid, Some(WaitPidFlag::WNOHANG)) {
            Ok(WaitStatus::Exited(_, code)) => {
                driver.report_death(DeathReason::Exit { code }, None);
                info!(target: "arca::exec-native::watch", pid = pid.as_raw(), code, "instancia exit");
                return;
            }
            Ok(WaitStatus::Signaled(_, sig, _)) => {
                driver.report_death(DeathReason::Signaled { signal: sig as i32 }, None);
                info!(target: "arca::exec-native::watch", pid = pid.as_raw(), signal = sig as i32, "instancia señal");
                return;
            }
            Ok(_) | Err(nix::errno::Errno::EINTR) => {
                std::thread::sleep(std::time::Duration::from_millis(REAP_POLL_MS));
            }
            Err(nix::errno::Errno::ECHILD) => {
                // Ya recolectado (doble waitpid tras kill): fail-closed.
                driver.report_death(DeathReason::Lost, None);
                return;
            }
            Err(e) => {
                warn!(target: "arca::exec-native::watch", err = %e, "waitpid");
                driver.report_death(DeathReason::Lost, None);
                return;
            }
        }
    }
}

/// Hilo de drain de stdout/stderr del hijo → tracing (target por app).
///
/// Ring de línea de 64 KB con drop-el-más-viejo (spec 14 §5): un hijo
/// parlanchín nunca bloquea (el pipe drena siempre).
pub(crate) fn drain_pipe(pipe: OwnedFd, app_id: String, canal: &'static str) {
    let mut buf = [0u8; 4096];
    let mut line = String::new();
    loop {
        match nix::unistd::read(pipe.as_fd(), &mut buf) {
            Ok(0) | Err(_) => break, // EOF (hijo murió) o error: fin
            Ok(n) => {
                line.push_str(&String::from_utf8_lossy(&buf[..n]));
                while let Some(pos) = line.find('\n') {
                    let (l, rest) = line.split_at(pos);
                    let l = l.trim_end_matches('\r');
                    if !l.is_empty() {
                        info!(target: "arca::exec-native::drain", app = %app_id, canal, "{l}");
                    }
                    line = rest[1..].to_owned();
                }
                if line.len() > 64 * 1024 {
                    line.drain(..line.len() - 64 * 1024);
                }
            }
        }
    }
}

/// PathBuf de utilidad interno (evita import huérfano en lib.rs).
#[allow(dead_code)]
pub(crate) fn _app_dir_marker(_p: &PathBuf) {}
